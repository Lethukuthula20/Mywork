<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = ''; // Set user ID to an empty string if not logged in
   header('location:user_login.php'); // Redirect to login page if not logged in
};

// Check if the delete button is clicked for a specific cart item
if(isset($_POST['delete'])){
   $cart_id = $_POST['cart_id']; // Get the cart ID from the form
   // Prepare and execute SQL statement to delete the cart item
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$cart_id]);
}

// Check if the delete all button is clicked
if(isset($_GET['delete_all'])){
   // Prepare and execute SQL statement to delete all cart items for the current user
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart_item->execute([$user_id]);
   header('location:cart.php'); // Redirect back to cart page after deletion
}

// Check if the update quantity button is clicked for a specific cart item
if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id']; // Get the cart ID from the form
   $qty = $_POST['qty']; // Get the updated quantity from the form
   $qty = filter_var($qty, FILTER_SANITIZE_STRING); // Sanitize the quantity input
   // Prepare and execute SQL statement to update the quantity of the cart item
   $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
   $update_qty->execute([$qty, $cart_id]);
   $message[] = 'cart quantity updated'; // Display a message confirming the update
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Shopping Cart</title>
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<!-- Shopping cart section -->
<section class="products shopping-cart">

   <h3 class="heading">Shopping cart</h3> <!-- Heading for the shopping cart section -->

   <div class="box-container">

   <?php
      $grand_total = 0;
      // Select cart items for the current user
      $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
      $select_cart->execute([$user_id]);
      if($select_cart->rowCount() > 0){
         while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
   ?>
   <!-- Cart item form -->
   <form action="" method="post" class="box">
      <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>"> <!-- Hidden input for cart ID -->
      <a href="quick_view.php?pid=<?= $fetch_cart['pid']; ?>" class="fas fa-eye"></a> <!-- Quick view link -->
      <img src="uploaded_img/<?= $fetch_cart['image']; ?>" alt=""> <!-- Product image -->
      <div class="name"><?= $fetch_cart['name']; ?></div> <!-- Product name -->
      <div class="flex">
         <div class="price">R <?= $fetch_cart['price']; ?></div> <!-- Product price -->
         <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="<?= $fetch_cart['quantity']; ?>"> <!-- Quantity input -->
         <button type="submit" class="fas fa-edit" name="update_qty"></button> <!-- Update quantity button -->
      </div>
      <div class="sub-total"> Sub Total : <span>R <?= $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?></span> </div> <!-- Subtotal -->
      <input type="submit" value="delete item" onclick="return confirm('delete this from cart?');" class="delete-btn" name="delete"> <!-- Delete item button -->
   </form>
   <?php
   $grand_total += $sub_total; // Calculate grand total
      }
   }else{
      echo '<p class="empty">Your cart is empty</p>'; // Display message if cart is empty
   }
   ?>
   </div>

   <!-- Cart total section -->
   <div class="cart-total">
      <p>Grand Total : <span>R <?= $grand_total; ?></span></p> <!-- Grand total -->
      <a href="shop.php" class="option-btn">Continue Shopping.</a> <!-- Continue shopping button -->
      <a href="cart.php?delete_all" class="delete-btn <?= ($grand_total > 1)?'':'disabled'; ?>" onclick="return confirm('delete all from cart?');">Delete All Items ?</a> <!-- Delete all items button -->
      <a href="checkout.php" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>">Proceed to Checkout.</a> <!-- Proceed to checkout button -->
   </div>

</section>













<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>