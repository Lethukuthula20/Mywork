<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Retrieve the admin ID from the session
$admin_id = $_SESSION['admin_id'];

// If the admin ID is not set, redirect to the admin login page
if(!isset($admin_id)){
   header('location:admin_login.php');
}

// If the delete parameter is set in the URL
if(isset($_GET['delete'])){
   // Retrieve the ID of the user to be deleted
   $delete_id = $_GET['delete'];
   
   // Prepare and execute queries to delete user-related information from various tables
   $delete_user = $conn->prepare("DELETE FROM `users` WHERE id = ?");
   $delete_user->execute([$delete_id]);
   
   $delete_orders = $conn->prepare("DELETE FROM `orders` WHERE user_id = ?");
   $delete_orders->execute([$delete_id]);
   
   $delete_messages = $conn->prepare("DELETE FROM `messages` WHERE user_id = ?");
   $delete_messages->execute([$delete_id]);
   
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart->execute([$delete_id]);
   
   $delete_wishlist = $conn->prepare("DELETE FROM `wishlist` WHERE user_id = ?");
   $delete_wishlist->execute([$delete_id]);
   
   // Redirect back to the user accounts page after deletion
   header('location:users_accounts.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Users accounts</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<!-- Include the admin header -->
<?php include '../components/admin_header.php'; ?>

<section class="accounts">

   <h1 class="heading">User accounts</h1>

   <div class="box-container">

   <?php
      // Select all user accounts from the database
      $select_accounts = $conn->prepare("SELECT * FROM `users`");
      $select_accounts->execute();
      
      // If there are user accounts available
      if($select_accounts->rowCount() > 0){
         // Loop through each user account
         while($fetch_accounts = $select_accounts->fetch(PDO::FETCH_ASSOC)){   
   ?>
   <!-- Display user account information in a box -->
   <div class="box">
      <p> User id : <span><?= $fetch_accounts['id']; ?></span> </p>
      <p> Username : <span><?= $fetch_accounts['name']; ?></span> </p>
      <p> Email : <span><?= $fetch_accounts['email']; ?></span> </p>
      <!-- Link to delete the user account -->
      <a href="users_accounts.php?delete=<?= $fetch_accounts['id']; ?>" onclick="return confirm('delete this account? the user related information will also be delete!')" class="delete-btn">delete</a>
   </div>
   <?php
         }
      }else{
         // If no user accounts are available, display a message
         echo '<p class="empty">no accounts available!</p>';
      }
   ?>

   </div>

</section>

<!-- Include custom admin scripts -->
<script src="../js/admin_script.js"></script>
   
</body>
</html>