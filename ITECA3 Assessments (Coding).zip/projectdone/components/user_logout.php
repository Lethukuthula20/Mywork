<?php

// Include the database connection file
include 'connect.php';

// Start a new session or resume the existing session
session_start();

// Unset all session variables to clear the session data
session_unset();

// Destroy the current session to remove all session data
session_destroy();

// Redirect the user to the home page after logging out
header('location:../home.php');

?>