<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is already logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = ''; // Set user ID to an empty string if not logged in
}

// Check if the form has been submitted
if(isset($_POST['send'])){

   // Sanitize and retrieve form input data
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING); // Sanitize the name
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING); // Sanitize the email
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING); // Sanitize the phone number
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING); // Sanitize the message

   // Check if the message already exists in the database
   $select_message = $conn->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

   // If the message already exists, set a message indicating so
   if($select_message->rowCount() > 0){
      $message[] = 'already sent message!';
   }else{
      // If the message does not exist, insert the new message into the database
      $insert_message = $conn->prepare("INSERT INTO `messages`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message[] = 'sent message successfully!'; // Set a message indicating success
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8"> <!-- Character encoding for the document -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibility mode for IE -->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport settings -->
   <title>Contact</title> <!-- Title of the document -->
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; // Include the user header ?>

<!-- Contact section -->
<section class="contact">
   <form action="" method="post"> <!-- Contact form -->
      <h3>Get in touch:</h3> <!-- Form heading -->
      <input type="text" name="name" placeholder="Enter your name" required maxlength="20" class="box"> <!-- Name input field -->
      <input type="email" name="email" placeholder="Enter your email" required maxlength="50" class="box"> <!-- Email input field -->
      <input type="number" name="number" min="0" max="9999999999" placeholder="Enter your number" required onkeypress="if(this.value.length == 10) return false;" class="box"> <!-- Phone number input field -->
      <textarea name="msg" class="box" placeholder="Enter your message" cols="30" rows="10"></textarea> <!-- Message textarea -->
      <input type="submit" value="send message" name="send" class="btn"> <!-- Submit button -->
   </form>
</section>

<?php include 'components/footer.php'; // Include the footer ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>