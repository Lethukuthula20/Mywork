<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Check if the form is submitted
if(isset($_POST['submit'])){

   // Get and sanitize the username
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   
   // Get and sanitize the password, then hash it using SHA-1
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   // Prepare the SQL statement to select the admin with the given username and password
   $select_admin = $conn->prepare("SELECT * FROM `admins` WHERE name = ? AND password = ?");
   // Execute the statement with the provided username and hashed password
   $select_admin->execute([$name, $pass]);
   // Fetch the result as an associative array
   $row = $select_admin->fetch(PDO::FETCH_ASSOC);

   // Check if a matching admin is found
   if($select_admin->rowCount() > 0){
      // Set the admin ID in the session
      $_SESSION['admin_id'] = $row['id'];
      // Redirect to the dashboard
      header('location:dashboard.php');
   }else{
      // Set an error message if the username or password is incorrect
      $message[] = 'incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php
   // Check if there are any messages to display
   if(isset($message)){
      // Loop through each message
      foreach($message as $message){
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>

<section class="form-container">

   <form action="" method="post">
      <h3>Login now</h3>
      <p>Default username = <span>admin</span> & password = <span>111</span></p>
      <!-- Input field for username -->
      <input type="text" name="name" required placeholder="Enter your username" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Input field for password -->
      <input type="password" name="pass" required placeholder="Enter your password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Submit button -->
      <input type="submit" value="login now" class="btn" name="submit">
   </form>

</section>
   
</body>
</html>