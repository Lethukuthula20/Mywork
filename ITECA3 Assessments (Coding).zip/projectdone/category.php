<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = ''; // Set user ID to an empty string if not logged in
};

// Include the wishlist and cart functionalities
include 'components/wishlist_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8"> <!-- Character encoding for the document -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibility mode for IE -->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport settings -->
   <title>Category</title> <!-- Title of the document -->
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; // Include the user header ?>

<!-- Products section -->
<section class="products">

   <h1 class="heading">Category</h1> <!-- Heading for the category section -->

   <div class="box-container">

   <?php
     // Get the category from the URL parameter
     $category = $_GET['category'];
     // Prepare and execute the SQL statement to select products matching the category
     $select_products = $conn->prepare("SELECT * FROM `products` WHERE name LIKE '%{$category}%'"); 
     $select_products->execute();
     if($select_products->rowCount() > 0){
      // Fetch and display each product
      while($fetch_product = $select_products->fetch(PDO::FETCH_ASSOC)){
   ?>
   <!-- Product form -->
   <form action="" method="post" class="box">
      <input type="hidden" name="pid" value="<?= $fetch_product['id']; ?>"> <!-- Hidden input for product ID -->
      <input type="hidden" name="name" value="<?= $fetch_product['name']; ?>"> <!-- Hidden input for product name -->
      <input type="hidden" name="price" value="<?= $fetch_product['price']; ?>"> <!-- Hidden input for product price -->
      <input type="hidden" name="image" value="<?= $fetch_product['image_01']; ?>"> <!-- Hidden input for product image -->
      <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button> <!-- Wishlist button -->
      <a href="quick_view.php?pid=<?= $fetch_product['id']; ?>" class="fas fa-eye"></a> <!-- Quick view link -->
      <img src="uploaded_img/<?= $fetch_product['image_01']; ?>" alt=""> <!-- Product image -->
      <div class="name"><?= $fetch_product['name']; ?></div> <!-- Product name -->
      <div class="flex">
         <div class="price"><span>R </span><?= $fetch_product['price']; ?><span></span></div> <!-- Product price -->
         <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1"> <!-- Quantity input -->
      </div>
      <input type="submit" value="add to cart" class="btn" name="add_to_cart"> <!-- Add to cart button -->
   </form>
   <?php
      }
   }else{
      echo '<p class="empty">no products found!</p>'; // Display message if no products are found
   }
   ?>

   </div>

</section>

<?php include 'components/footer.php'; // Include the footer ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>