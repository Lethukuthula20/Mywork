<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Retrieve the admin ID from the session
$admin_id = $_SESSION['admin_id'];

// If the admin ID is not set, redirect to the admin login page
if(!isset($admin_id)){
   header('location:admin_login.php');
}

// If the update payment form is submitted
if(isset($_POST['update_payment'])){
   $order_id = $_POST['order_id'];  // Get the order ID from the form
   $payment_status = $_POST['payment_status'];  // Get the new payment status from the form
   $payment_status = filter_var($payment_status, FILTER_SANITIZE_STRING);  // Sanitize the payment status
   $update_payment = $conn->prepare("UPDATE `orders` SET payment_status = ? WHERE id = ?");  // Prepare the update query
   $update_payment->execute([$payment_status, $order_id]);  // Execute the query with the new payment status and order ID
   $message[] = 'payment status updated!';  // Add a success message
}

// If a delete request is made
if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];  // Get the ID of the order to delete
   $delete_order = $conn->prepare("DELETE FROM `orders` WHERE id = ?");  // Prepare the delete query
   $delete_order->execute([$delete_id]);  // Execute the query with the order ID
   header('location:placed_orders.php');  // Redirect to the placed orders page
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Placed Orders.</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<!-- Include the admin header -->
<?php include '../components/admin_header.php'; ?>

<section class="orders">

<h1 class="heading">Placed Orders.</h1>

<div class="box-container">

   <?php
      // Select all orders from the database
      $select_orders = $conn->prepare("SELECT * FROM `orders`");
      $select_orders->execute();

      // If there are orders, display them
      if($select_orders->rowCount() > 0){
         while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="box">
      <p> Placed On : <span><?= $fetch_orders['placed_on']; ?></span> </p>
      <p> Name : <span><?= $fetch_orders['name']; ?></span> </p>
      <p> Number : <span><?= $fetch_orders['number']; ?></span> </p>
      <p> Address : <span><?= $fetch_orders['address']; ?></span> </p>
      <p> Total products : <span><?= $fetch_orders['total_products']; ?></span> </p>
      <p> Total price : <span>R <?= $fetch_orders['total_price']; ?></span> </p>
      <p> Payment method : <span><?= $fetch_orders['method']; ?></span> </p>
      <form action="" method="post">
         <input type="hidden" name="order_id" value="<?= $fetch_orders['id']; ?>">  <!-- Hidden input to hold the order ID -->
         <select name="payment_status" class="select">
            <option selected disabled><?= $fetch_orders['payment_status']; ?></option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="canceled">Canceled</option>
         </select>
        <div class="flex-btn">
         <input type="submit" value="update" class="option-btn" name="update_payment">  <!-- Update button to submit the form -->
         <a href="placed_orders.php?delete=<?= $fetch_orders['id']; ?>" class="delete-btn" onclick="return confirm('delete this order?');">delete</a>  <!-- Delete button with a confirmation prompt -->
        </div>
      </form>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">no orders placed yet!</p>';  // If there are no orders, display this
      }
   ?>

</div>

</section>

</section>

<!-- Link to custom admin scripts -->
<script src="../js/admin_script.js"></script>
   
</body>
</html>