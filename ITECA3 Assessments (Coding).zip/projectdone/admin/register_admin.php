<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Retrieve the admin ID from the session
$admin_id = $_SESSION['admin_id'];

// If the admin ID is not set, redirect to the admin login page
if(!isset($admin_id)){
   header('location:admin_login.php');
}

// If the registration form is submitted
if(isset($_POST['submit'])){

   // Retrieve and sanitize form inputs
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']); // Hash the password using sha1
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']); // Hash the confirm password using sha1
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   // Check if the admin username already exists in the database
   $select_admin = $conn->prepare("SELECT * FROM `admins` WHERE name = ?");
   $select_admin->execute([$name]);

   // If username already exists, display a message
   if($select_admin->rowCount() > 0){
      $message[] = 'username already exist!';
   }else{
      // Check if the password and confirm password match
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         // Insert the new admin into the database
         $insert_admin = $conn->prepare("INSERT INTO `admins`(name, password) VALUES(?,?)");
         $insert_admin->execute([$name, $cpass]);
         $message[] = 'new admin registered successfully!';
      }
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register Admin</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<!-- Include the admin header -->
<?php include '../components/admin_header.php'; ?>

<section class="form-container">

   <form action="" method="post">
      <h3>Register Now</h3>
      <!-- Username input field with whitespace removal -->
      <input type="text" name="name" required placeholder="Enter your username" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Password input field with whitespace removal -->
      <input type="password" name="pass" required placeholder="Enter your password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Confirm password input field with whitespace removal -->
      <input type="password" name="cpass" required placeholder="Confirm your password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Submit button -->
      <input type="submit" value="register now" class="btn" name="submit">
   </form>

</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>