<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is already logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = ''; // Set user ID to an empty string if not logged in
}

// Include the wishlist and cart handling script
include 'components/wishlist_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8"> <!-- Character encoding for the document -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibility mode for IE -->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport settings -->
   <title>Search page</title> <!-- Title of the document -->
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; // Include the user header ?>

<!-- Search form section -->
<section class="search-form">
   <form action="" method="post">
      <input type="text" name="search_box" placeholder="search here..." maxlength="100" class="box" required> <!-- Input for search query -->
      <button type="submit" class="fas fa-search" name="search_btn"></button> <!-- Search button -->
   </form>
</section>

<!-- Products section -->
<section class="products" style="padding-top: 0; min-height:100vh;">

   <div class="box-container">

   <?php
     // Check if the search form is submitted
     if(isset($_POST['search_box']) OR isset($_POST['search_btn'])){
       // Get the search query from the form
       $search_box = $_POST['search_box'];
       // Prepare an SQL statement to search for products matching the search query
       $select_products = $conn->prepare("SELECT * FROM `products` WHERE name LIKE '%{$search_box}%'"); 
       $select_products->execute();
       
       // Check if there are any products matching the search query
       if($select_products->rowCount() > 0){
         // Loop through each product and display it
         while($fetch_product = $select_products->fetch(PDO::FETCH_ASSOC)){
   ?>
   <!-- Form for each product to add to wishlist or cart -->
   <form action="" method="post" class="box">
      <input type="hidden" name="pid" value="<?= $fetch_product['id']; ?>"> <!-- Hidden field for product ID -->
      <input type="hidden" name="name" value="<?= $fetch_product['name']; ?>"> <!-- Hidden field for product name -->
      <input type="hidden" name="price" value="<?= $fetch_product['price']; ?>"> <!-- Hidden field for product price -->
      <input type="hidden" name="image" value="<?= $fetch_product['image_01']; ?>"> <!-- Hidden field for product image -->
      <button class="fas fa-heart" type="submit" name="add_to_wishlist"></button> <!-- Button to add to wishlist -->
      <a href="quick_view.php?pid=<?= $fetch_product['id']; ?>" class="fas fa-eye"></a> <!-- Link to view product details -->
      <img src="uploaded_img/<?= $fetch_product['image_01']; ?>" alt=""> <!-- Product image -->
      <div class="name"><?= $fetch_product['name']; ?></div> <!-- Product name -->
      <div class="flex">
         <div class="price"><span>R </span><?= $fetch_product['price']; ?><span></span></div> <!-- Product price -->
         <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1"> <!-- Quantity input field -->
      </div>
      <input type="submit" value="add to cart" class="btn" name="add_to_cart"> <!-- Button to add to cart -->
   </form>
   <?php
         }
      }else{
         // Message if no products are found
         echo '<p class="empty">no products found!</p>';
      }
   }
   ?>

   </div>

</section>

<?php include 'components/footer.php'; // Include the footer ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>