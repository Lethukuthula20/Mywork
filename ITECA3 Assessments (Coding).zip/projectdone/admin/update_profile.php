<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Retrieve the admin ID from the session
$admin_id = $_SESSION['admin_id'];

// If the admin ID is not set, redirect to the admin login page
if(!isset($admin_id)){
   header('location:admin_login.php');
}

// If the update profile form is submitted
if(isset($_POST['submit'])){

   // Retrieve and sanitize form inputs for updating username
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);

   // Update the username in the database
   $update_profile_name = $conn->prepare("UPDATE `admins` SET name = ? WHERE id = ?");
   $update_profile_name->execute([$name, $admin_id]);

   // Handle password update
   $empty_pass = 'da39a3ee5e6b4b0d3255bfef95601890afd80709';
   $prev_pass = $_POST['prev_pass'];
   $old_pass = sha1($_POST['old_pass']);
   $old_pass = filter_var($old_pass, FILTER_SANITIZE_STRING);
   $new_pass = sha1($_POST['new_pass']);
   $new_pass = filter_var($new_pass, FILTER_SANITIZE_STRING);
   $confirm_pass = sha1($_POST['confirm_pass']);
   $confirm_pass = filter_var($confirm_pass, FILTER_SANITIZE_STRING);

   // Check if old password is empty
   if($old_pass == $empty_pass){
      $message[] = 'please enter old password!';
   }
   // Check if old password matches the previous password
   elseif($old_pass != $prev_pass){
      $message[] = 'old password not matched!';
   }
   // Check if new password matches the confirmed password
   elseif($new_pass != $confirm_pass){
      $message[] = 'confirm password not matched!';
   }
   // If all checks pass, update the password
   else{
      // Check if a new password is entered
      if($new_pass != $empty_pass){
         // Update the password in the database
         $update_admin_pass = $conn->prepare("UPDATE `admins` SET password = ? WHERE id = ?");
         $update_admin_pass->execute([$confirm_pass, $admin_id]);
         $message[] = 'password updated successfully!';
      }else{
         $message[] = 'please enter a new password!';
      }
   }
   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Profile</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<!-- Include the admin header -->
<?php include '../components/admin_header.php'; ?>

<section class="form-container">

   <!-- Profile update form -->
   <form action="" method="post">
      <h3>Update Profile</h3>
      <!-- Hidden field to store the previous password -->
      <input type="hidden" name="prev_pass" value="<?= $fetch_profile['password']; ?>">
      <!-- Input field to update username -->
      <input type="text" name="name" value="<?= $fetch_profile['name']; ?>" required placeholder="Enter your username" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Input fields to update passwords -->
      <input type="password" name="old_pass" placeholder="Enter old password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="new_pass" placeholder="Enter new password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="confirm_pass" placeholder="Confirm new password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Submit button to update profile -->
      <input type="submit" value="update now" class="btn" name="submit">
   </form>

</section>

<!-- Include custom admin scripts -->
<script src="../js/admin_script.js"></script>
   
</body>
</html>