<?php
   // Check if there are any messages to display
   if(isset($message)){
      // Loop through each message
      foreach($message as $message){
         // Display each message inside a div with a close button
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>

<!-- Header section -->
<header class="header">

   <section class="flex">

      <!-- Admin Panel logo with link to dashboard -->
      <a href="../admin/dashboard.php" class="logo">Admin<span>Panel</span></a>

      <!-- Navigation bar with links to different admin pages -->
      <nav class="navbar">
         <a href="../admin/dashboard.php">Home</a>
         <a href="../admin/products.php">Products</a>
         <a href="../admin/placed_orders.php">Orders</a>
         <a href="../admin/admin_accounts.php">Admins</a>
         <a href="../admin/users_accounts.php">Users</a>
         <a href="../admin/messages.php">Messages</a>
      </nav>

      <!-- Icons for menu and user profile -->
      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
      </div>

      <!-- Profile section -->
      <div class="profile">
         <?php
            // Fetch the admin profile information from the database
            $select_profile = $conn->prepare("SELECT * FROM `admins` WHERE id = ?");
            $select_profile->execute([$admin_id]);
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <!-- Display the admin's name -->
         <p><?= $fetch_profile['name']; ?></p>
         <!-- Link to update profile page -->
         <a href="../admin/update_profile.php" class="btn">Update Profile</a>
         <!-- Buttons for registering a new admin and admin login -->
         <div class="flex-btn">
            <a href="../admin/register_admin.php" class="option-btn">Register</a>
            <a href="../admin/admin_login.php" class="option-btn">Login</a>
         </div>
         <!-- Logout button with confirmation prompt -->
         <a href="../components/admin_logout.php" class="delete-btn" onclick="return confirm('logout from the website?');">logout</a> 
      </div>

   </section>

</header>