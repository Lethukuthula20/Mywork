<?php

// Include the database connection script
include '../components/connect.php';

// Start the session
session_start();

// Retrieve the admin ID from the session
$admin_id = $_SESSION['admin_id'];

// If the admin ID is not set, redirect to the admin login page
if(!isset($admin_id)){
   header('location:admin_login.php');
};

// If a delete request is made
if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];  // Get the ID of the message to delete
   $delete_message = $conn->prepare("DELETE FROM `messages` WHERE id = ?");  // Prepare the delete query
   $delete_message->execute([$delete_id]);  // Execute the query with the message ID
   header('location:messages.php');  // Redirect to the messages page
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Messages</title>

   <!-- Link to Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Link to custom admin styles -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<!-- Include the admin header -->
<?php include '../components/admin_header.php'; ?>

<section class="contacts">

<h1 class="heading">Messages</h1>

<div class="box-container">

   <?php
      // Select all messages from the database
      $select_messages = $conn->prepare("SELECT * FROM `messages`");
      $select_messages->execute();

      // If there are messages, display them
      if($select_messages->rowCount() > 0){
         while($fetch_message = $select_messages->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="box">
      <p> User id : <span><?= $fetch_message['user_id']; ?></span></p>
      <p> Name : <span><?= $fetch_message['name']; ?></span></p>
      <p> Email : <span><?= $fetch_message['email']; ?></span></p>
      <p> Number : <span><?= $fetch_message['number']; ?></span></p>
      <p> Message : <span><?= $fetch_message['message']; ?></span></p>
      <a href="messages.php?delete=<?= $fetch_message['id']; ?>" onclick="return confirm('delete this message?');" class="delete-btn">Delete</a>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">you have no messages</p>';  // If there are no messages, display this
      }
   ?>

</div>

</section>

<!-- Link to custom admin scripts -->
<script src="../js/admin_script.js"></script>
   
</body>
</html>