<?php

// Include the file that contains the database connection information
include 'components/connect.php';

// Start a PHP session to store session variables
session_start();

// Check if the 'user_id' session variable is set
if(isset($_SESSION['user_id'])){
   // If set, assign its value to $user_id
   $user_id = $_SESSION['user_id'];
}else{
   // If not set, initialize $user_id as an empty string
   $user_id = '';
};

// Check if the form has been submitted
if(isset($_POST['submit'])){

   // Sanitize and retrieve input values from the POST array
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']); // Hash the password using SHA1 (Note: SHA1 is not recommended for password hashing)
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']); // Hash the confirm password using SHA1
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   // Prepare and execute a SELECT query to check if the email already exists in the database
   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
   $select_user->execute([$email,]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   // Check if a row with the email already exists in the database
   if($select_user->rowCount() > 0){
      // If exists, add a message indicating that the email already exists to the $message array
      $message[] = 'email already exists!';
   }else{
      // If the email doesn't exist in the database
      if($pass != $cpass){
         // Check if the password and confirm password fields match
         // If not, add a message indicating that the confirm password does not match to the $message array
         $message[] = 'confirm password not matched!';
      }else{
         // If the passwords match, prepare and execute an INSERT query to add the new user to the database
         $insert_user = $conn->prepare("INSERT INTO `users`(name, email, password) VALUES(?,?,?)");
         $insert_user->execute([$name, $email, $cpass]);
         // Add a success message to the $message array indicating that the user has been registered successfully
         $message[] = 'registered successfully, login now please!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="form-container">

   <!-- Register Form -->
   <form action="" method="post">
      <h3>Register Now</h3>
      <input type="text" name="name" required placeholder="Enter your username" maxlength="20"  class="box">
      <input type="email" name="email" required placeholder="Enter your email" maxlength="50"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" required placeholder="Enter your password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" required placeholder="Confirm your password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="register now" class="btn" name="submit">
      <p>Already have an account?</p>
      <a href="user_login.php" class="option-btn">Login Now</a>
   </form>

</section>

<?php include 'components/footer.php'; ?>

<!-- JavaScript file -->
<script src="js/script.js"></script>

</body>
</html>