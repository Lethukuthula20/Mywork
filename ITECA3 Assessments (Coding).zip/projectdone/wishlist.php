<?php

// Include the file that contains the database connection information
include 'components/connect.php';

// Start a PHP session to store session variables
session_start();

// Check if the 'user_id' session variable is set
if(isset($_SESSION['user_id'])){
   // If set, assign its value to $user_id
   $user_id = $_SESSION['user_id'];
}else{
   // If not set, initialize $user_id as an empty string
   $user_id = '';
   // Redirect to the user login page if the user is not logged in
   header('location:user_login.php');
};

// Include the file that contains the wishlist and cart functionalities
include 'components/wishlist_cart.php';

// Check if the delete button for a wishlist item is clicked
if(isset($_POST['delete'])){
   // Retrieve the wishlist item ID from the form
   $wishlist_id = $_POST['wishlist_id'];
   // Prepare and execute a DELETE query to remove the wishlist item from the database
   $delete_wishlist_item = $conn->prepare("DELETE FROM `wishlist` WHERE id = ?");
   $delete_wishlist_item->execute([$wishlist_id]);
}

// Check if the delete all button is clicked
if(isset($_GET['delete_all'])){
   // Prepare and execute a DELETE query to remove all wishlist items for the current user from the database
   $delete_wishlist_item = $conn->prepare("DELETE FROM `wishlist` WHERE user_id = ?");
   $delete_wishlist_item->execute([$user_id]);
   // Redirect back to the wishlist page after deleting all items
   header('location:wishlist.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Wishlist</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="products">

   <!-- Display the heading for the wishlist section -->
   <h3 class="heading">Your Wishlist.</h3>

   <div class="box-container">

   <?php
      // Initialize the grand total variable
      $grand_total = 0;
      // Prepare and execute a SELECT query to retrieve wishlist items for the current user
      $select_wishlist = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
      $select_wishlist->execute([$user_id]);
      // Check if there are any wishlist items for the current user
      if($select_wishlist->rowCount() > 0){
         // Loop through each wishlist item
         while($fetch_wishlist = $select_wishlist->fetch(PDO::FETCH_ASSOC)){
            // Calculate the grand total by adding the price of each item
            $grand_total += $fetch_wishlist['price'];  
   ?>
   <!-- Display the wishlist item as a form -->
   <form action="" method="post" class="box">
      <!-- Store necessary information about the wishlist item as hidden inputs -->
      <input type="hidden" name="pid" value="<?= $fetch_wishlist['pid']; ?>">
      <input type="hidden" name="wishlist_id" value="<?= $fetch_wishlist['id']; ?>">
      <input type="hidden" name="name" value="<?= $fetch_wishlist['name']; ?>">
      <input type="hidden" name="price" value="<?= $fetch_wishlist['price']; ?>">
      <input type="hidden" name="image" value="<?= $fetch_wishlist['image']; ?>">
      <!-- Display an icon to view the item details -->
      <a href="quick_view.php?pid=<?= $fetch_wishlist['pid']; ?>" class="fas fa-eye"></a>
      <!-- Display the item image -->
      <img src="uploaded_img/<?= $fetch_wishlist['image']; ?>" alt="">
      <!-- Display the item name -->
      <div class="name"><?= $fetch_wishlist['name']; ?></div>
      <div class="flex">
         <!-- Display the item price -->
         <div class="price">R <?= $fetch_wishlist['price']; ?></div>
         <!-- Input field to select the quantity of the item -->
         <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
      </div>
      <!-- Button to add the item to the cart -->
      <input type="submit" value="add to cart" class="btn" name="add_to_cart">
      <!-- Button to delete the item from the wishlist -->
      <input type="submit" value="delete item" onclick="return confirm('delete this from wishlist?');" class="delete-btn" name="delete">
   </form>
   <?php
      }
   }else{
      // If the wishlist is empty, display a message
      echo '<p class="empty">Your wishlist is empty</p>';
   }
   ?>
   </div>

   <!-- Display the total price of all items in the wishlist -->
   <div class="wishlist-total">
      <p>Grand Total : <span>R <?= $grand_total; ?></span></p>
      <!-- Button to continue shopping -->
      <a href="shop.php" class="option-btn">Continue Shopping.</a>
      <!-- Button to delete all items from the wishlist -->
      <a href="wishlist.php?delete_all" class="delete-btn <?= ($grand_total > 1)?'':'disabled'; ?>" onclick="return confirm('delete all from wishlist?');">delete all item</a>
   </div>

</section>

<?php include 'components/footer.php'; ?>

<!-- JavaScript file -->
<script src="js/script.js"></script>

</body>
</html>