<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is already logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = ''; // Set user ID to an empty string if not logged in
}

// Check if the form has been submitted
if(isset($_POST['submit'])){

   // Retrieve and sanitize the name and email input
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);

   // Prepare a SQL statement to update the user's name and email
   $update_profile = $conn->prepare("UPDATE `users` SET name = ?, email = ? WHERE id = ?");
   $update_profile->execute([$name, $email, $user_id]); // Execute the statement with the provided name, email, and user ID

   // Define an empty password hash for comparison
   $empty_pass = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'; // SHA1 hash of an empty string
   $prev_pass = $_POST['prev_pass']; // Previous password from the form
   $old_pass = sha1($_POST['old_pass']); // Hash the old password input
   $old_pass = filter_var($old_pass, FILTER_SANITIZE_STRING); // Sanitize the hashed old password
   $new_pass = sha1($_POST['new_pass']); // Hash the new password input
   $new_pass = filter_var($new_pass, FILTER_SANITIZE_STRING); // Sanitize the hashed new password
   $cpass = sha1($_POST['cpass']); // Hash the confirm password input
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING); // Sanitize the hashed confirm password

   // Check if the old password is provided
   if($old_pass == $empty_pass){
      $message[] = 'please enter old password!'; // Error message if old password is not entered
   }elseif($old_pass != $prev_pass){
      // Check if the old password matches the previous password
      $message[] = 'old password not matched!'; // Error message if old password does not match
   }elseif($new_pass != $cpass){
      // Check if the new password matches the confirm password
      $message[] = 'confirm password not matched!'; // Error message if new password and confirm password do not match
   }else{
      // Check if the new password is not empty
      if($new_pass != $empty_pass){
         // Prepare a SQL statement to update the user's password
         $update_admin_pass = $conn->prepare("UPDATE `users` SET password = ? WHERE id = ?");
         $update_admin_pass->execute([$cpass, $user_id]); // Execute the statement with the new password and user ID
         $message[] = 'password updated successfully!'; // Success message
      }else{
         $message[] = 'please enter a new password!'; // Error message if new password is empty
      }
   }
   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8"> <!-- Character encoding for the document -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibility mode for IE -->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport -->
   <title>Register</title> <!-- Title of the document -->
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; // Include the user header ?>

<section class="form-container">

   <!-- Profile update form -->
   <form action="" method="post">
      <h3>Update now</h3>
      <!-- Hidden field to store the previous password -->
      <input type="hidden" name="prev_pass" value="<?= $fetch_profile["password"]; ?>">
      <!-- Input field for the username -->
      <input type="text" name="name" required placeholder="Enter your username" maxlength="20"  class="box" value="<?= $fetch_profile["name"]; ?>">
      <!-- Input field for the email -->
      <input type="email" name="email" required placeholder="Enter your email" maxlength="50"  class="box" oninput="this.value = this.value.replace(/\s/g, '')" value="<?= $fetch_profile["email"]; ?>">
      <!-- Input field for the old password -->
      <input type="password" name="old_pass" placeholder="Enter your old password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Input field for the new password -->
      <input type="password" name="new_pass" placeholder="Enter your new password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Input field to confirm the new password -->
      <input type="password" name="cpass" placeholder="Confirm your new password" maxlength="20"  class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <!-- Submit button to update profile -->
      <input type="submit" value="update now" class="btn" name="submit">
   </form>

</section>

<?php include 'components/footer.php'; // Include the footer ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>