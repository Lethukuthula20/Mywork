// Selecting the navbar and profile elements from the DOM
let navbar = document.querySelector('.header .flex .navbar');
let profile = document.querySelector('.header .flex .profile');

// Handling click event for the menu button
document.querySelector('#menu-btn').onclick = () =>{
   // Toggling the 'active' class on the navbar element
   navbar.classList.toggle('active');
   // Removing the 'active' class from the profile element
   profile.classList.remove('active');
}

// Handling click event for the user button
document.querySelector('#user-btn').onclick = () =>{
   // Toggling the 'active' class on the profile element
   profile.classList.toggle('active');
   // Removing the 'active' class from the navbar element
   navbar.classList.remove('active');
}

// Handling scroll event on the window
window.onscroll = () =>{
   // Removing the 'active' class from both navbar and profile elements when scrolling
   navbar.classList.remove('active');
   profile.classList.remove('active');
}

// Selecting the main image element
let mainImage = document.querySelector('.quick-view .box .row .image-container .main-image img');
// Selecting all sub-image elements
let subImages = document.querySelectorAll('.quick-view .box .row .image-container .sub-image img');

// Iterating over each sub-image element
subImages.forEach(images =>{
   // Adding a click event listener to each sub-image element
   images.onclick = () =>{
      // Getting the source attribute of the clicked sub-image
      src = images.getAttribute('src');
      // Setting the source attribute of the main image to the clicked sub-image source
      mainImage.src = src;
   }
});