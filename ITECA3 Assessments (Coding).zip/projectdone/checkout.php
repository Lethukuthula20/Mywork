<?php

// Include the database connection file
include 'components/connect.php';

// Start the session to access session variables
session_start();

// Check if the user is logged in
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id']; // Get the user ID from the session
}else{
   $user_id = '';
   header('location:user_login.php'); // Redirect to the login page if not logged in
};

// Check if the order form has been submitted
if(isset($_POST['order'])){

   // Sanitize and retrieve form input data
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING); // Sanitize the name
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING); // Sanitize the phone number
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING); // Sanitize the email
   $method = $_POST['method'];
   $method = filter_var($method, FILTER_SANITIZE_STRING); // Sanitize the payment method
   $address = 'flat no. '. $_POST['flat'] .', '. $_POST['street'] .', '. $_POST['city'] .', '. $_POST['state'] .', '. $_POST['country'] .' - '. $_POST['pin_code'];
   $address = filter_var($address, FILTER_SANITIZE_STRING); // Sanitize the address
   $total_products = $_POST['total_products'];
   $total_price = $_POST['total_price'];

   // Check if there are items in the user's cart
   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      // Insert the order into the orders table
      $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?,?)");
      $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $total_price]);

      // Clear the cart after placing the order
      $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
      $delete_cart->execute([$user_id]);

      $message[] = 'order placed successfully!'; // Set a success message
   }else{
      $message[] = 'your cart is empty'; // Set a message indicating the cart is empty
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8"> <!-- Character encoding for the document -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibility mode for IE -->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport settings -->
   <title>checkout</title> <!-- Title of the document -->
   
   <!-- Font Awesome CDN link for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; // Include the user header ?>

<!-- Checkout orders section -->
<section class="checkout-orders">

   <!-- Order form -->
   <form action="" method="POST">

   <h3>Your Orders</h3> <!-- Heading for the orders section -->

      <div class="display-orders">
      <?php
         $grand_total = 0; // Initialize grand total
         $cart_items[] = ''; // Initialize an array to hold cart items
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
               $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].' x '. $fetch_cart['quantity'].') - '; // Add item to cart items array
               $total_products = implode($cart_items); // Convert array to string
               $grand_total += ($fetch_cart['price'] * $fetch_cart['quantity']); // Calculate the grand total
      ?>
         <p> <?= $fetch_cart['name']; ?> <span>(<?= '$'.$fetch_cart['price'].'/- x '. $fetch_cart['quantity']; ?>)</span> </p>
      <?php
            }
         }else{
            echo '<p class="empty">your cart is empty!</p>'; // Display message if the cart is empty
         }
      ?>
         <input type="hidden" name="total_products" value="<?= $total_products; ?>"> <!-- Hidden input for total products -->
         <input type="hidden" name="total_price" value="<?= $grand_total; ?>"> <!-- Hidden input for total price -->
         <div class="grand-total">Grand Total : <span>R <?= $grand_total; ?></span></div> <!-- Display grand total -->
      </div>

      <h3>place your orders</h3> <!-- Heading for the order placement section -->

      <div class="flex">
         <!-- Input fields for order details -->
         <div class="inputBox">
            <span>Your Name :</span>
            <input type="text" name="name" placeholder="Enter your name" class="box" maxlength="20" required>
         </div>
         <div class="inputBox">
            <span>Your Number :</span>
            <input type="number" name="number" placeholder="Enter your number" class="box" min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false;" required>
         </div>
         <div class="inputBox">
            <span>Your Email :</span>
            <input type="email" name="email" placeholder="Enter your email" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Payment Method :</span>
            <select name="method" class="box" required>
               <option value="cash on delivery">Cash On Delivery</option>
               <option value="credit card">Credit Card</option>
               <option value="paytm">eSewa</option>
               <option value="paypal">Khalti</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Address line 01 :</span>
            <input type="text" name="flat" placeholder="e.g. Flat number" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Address line 02 :</span>
            <input type="text" name="street" placeholder="Street name" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>City :</span>
            <input type="text" name="city" placeholder="Johannesburg" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Province:</span>
            <input type="text" name="state" placeholder="Gauteng" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Country :</span>
            <input type="text" name="country" placeholder="South Africa" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>ZIP CODE :</span>
            <input type="number" min="0" name="pin_code" placeholder="e.g. 1401" min="0" max="999999" onkeypress="if(this.value.length == 6) return false;" class="box" required>
         </div>
      </div>

      <!-- Submit button for placing the order -->
      <input type="submit" name="order" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>" value="place order">

   </form>

</section>

<?php include 'components/footer.php'; // Include the footer ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>